let cs = canvasSize
let lc = layerCount
let tc = traitCounts
let bgf = bgFormat
let codeBy = " | code by Shane Robinson @LimnDigital"

document.title = (document.title) ? document.title : projectName + " by " + artistName + " | fx(hash)" + codeBy

console.log("========== fx(hash) Random Hashes ==========")
console.log("fxhash: " + fxhash)   // the 64 chars hex number fed to your algorithm
console.log("fxrand: " + fxrand()) // deterministic PRNG function, use it instead of Math.random()
console.log("========== Template & Core Code Credit ==========")
console.log("Originally Published February 2022 - Core Code ©2022 Shane Robinson, All Rights Reserved")
console.log("Core Code: Shane Robinson as @LimnDigital, https://twitter.com/limndigital")
console.log("Want help with Your fx(hash) Projects? Follow and DM @LimnDigital on Twitter. ;-)")
console.log("This template available https://github.com/limndigital/fxhash-low-code-gap-template")
console.log("This template licensed under MIT License: https://github.com/limndigital/fxhash-low-code-gap-template/blob/main/LICENSE")
console.log("========== Live Mode keyPress for Downloads ==========")
console.log("In Live Mode: keyPress to save Artworks:")
console.log("'s' or 'S' to save at current canvas size.")
console.log("'f' or 'F' to save at full size, 2048 x 2048px.")
console.log("'t' or 'T' to save at Twitter Tweet size, 1200 x 1200px.")


// obfuscate the Layer Traits dir using https://obfuscator.io/
// Call the Layer Traits anything you want. 
// Just break up the name into 3 parts across the dx vars below. 8-D
let d1 = 'la'
let d2 = 'yer' 
let d3 = 's'
// import p5.js here so bundle works correctly
let sketch = (sk) => {
  // Setup global arrays
  let r = []  // Array: randomly selected trait in each Layer folder
  let g = []  // Array: loadImage to hold each graphic selected from r[] array
  let w, h // setup for window width & height in Canvas create and window resize
  
  // Setup a randInt() b/c we need to use fxrand instead of p5's native random()
  function randInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(fxrand() * (max - min)) + min;
  }

  // Preload ONLY our randomly selected trait graphics (not everything like most Projects do)  
  sk.preload = function () {
    for (let i = 0; i < lc; i++) {
      // get a random trait # from each trait Layer folder
      r[i] = sk.int(randInt(0, tc[i]))
      // assign trait graphic path for each random trait layer graphic
      // first check to see if it's iteration 0 (background)
      // and what we have bgf set to... Else we're going to assume we want PNG
      
      bgf = (i === 0) ? bgf : ".png"
      g[i] = sk.loadImage('./' + d1 + d2 + d3 + '/' + i + '/' + r[i] + bgf)
    }
  }

  sk.setup = function () {
    sk.noLoop()

  // I'm sure there's a better, easier way to track & manage canvas display?
  // Using this for now because want canvas to maintain ration no matter what initial window size/ratio
  w = (sk.windowWidth > cs) ? cs : (sk.windowWidth < sk.windowHeight) ? sk.windowWidth : sk.windowHeight
  h = (sk.windowHeight > cs) ? cs : (sk.windowHeight > sk.windowWidth) ? sk.windowWidth : sk.windowHeight
  w = (w > h) ? h : w
  h = (h > w) ? w : h
    // Create the canvas based on initial window size
    sk.createCanvas(w, h)
  }

  // Manage window resizing windowResized
  sk.windowResized = function () {
    // Have to repeat everytime window is resized. Can't share with globals
    w = (sk.windowWidth > cs) ? cs : (sk.windowWidth < sk.windowHeight) ? sk.windowWidth : sk.windowHeight
    h = (sk.windowHeight > cs) ? cs : (sk.windowHeight > sk.windowWidth) ? sk.windowWidth : sk.windowHeight
    w = (w > h) ? h : w
    h = (h > w) ? w : h
    sk.resizeCanvas(w, h);
  }

  // Draw the Magic
  sk.draw = function () {
    for (let i = 0; i < lc; i++) {
      sk.image(g[i], 0, 0, sk.width, sk.height)
    }
  }

  // Viewers can download generated Artwork by pressing key set in 'dlk' at top.
  sk.keyTyped = function () {
    if (sk.key === dlc || sk.key === dlc.toUpperCase()) {
      sk.save(dlFile + "-" + w + "px" + "-hash-" + fxhash)
    }
    if (sk.key === dlf || sk.key === dlf.toUpperCase()) {
      sk.pixelDensity(1)
      sk.createCanvas(cs, cs)
      sk.draw()
      sk.save(dlFile + "-" + cs + "px" + "-hash-" + fxhash) 
    }
    if (sk.key === dlt || sk.key === dlt.toUpperCase()) {
      sk.pixelDensity(1)
      sk.createCanvas(1200, 1200)
      sk.draw()
      sk.save(dlFile + "-twitter-1200px-hash-" + fxhash) 
    }
  }
  
} // close let sketch function

// Do it... DO IT!!
const P5 = new p5(sketch) 